import React from 'react'

const MainDashboard = () => {
  return (
    <div>MainDashboard</div>
  )
}

export default MainDashboard