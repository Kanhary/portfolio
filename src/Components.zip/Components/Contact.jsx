import React from 'react'
import { FaGithub } from "react-icons/fa";
import { FaTelegram } from "react-icons/fa";

const Contact = () => {
  return (
        <section className="px-6 md:px-16 py-16 font-khmer">
      {/* <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">Get in Touch</h2>
        <p className="text-gray-600 mb-10">
          Have a question, feedback, or just want to say hello? I'd love to hear from you.
        </p>
      </div>

      <div>
        <div>
          <div>
            <a href=""><FaGithub /></a>
            <a href=""><FaTelegram /></a>
          </div>
        </div>
        <div>
          <form className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-md space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
              <input
                type="email"
                placeholder="Your Email"
                className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
                required
              />
            </div>
            <textarea
              rows="5"
              placeholder="Your Message"
              className="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400"
              required
            ></textarea>
            <div className="text-center">
              <button
                type="submit"
                className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-500 transition"
              >
                Send Message
              </button>
            </div>
          </form>
        </div>
      </div> */}
    </section>
  )
}

export default Contact